package org.arquillian.a;

import javax.inject.Named;

@Named
public class Handler
{
   public String invoke() {
      return "handler";
   }

}
