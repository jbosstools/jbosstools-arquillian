package org.arquillian.a;

public class Resource {

}
