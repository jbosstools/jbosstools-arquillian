package org.arquillian.a;

import javax.inject.Inject;
import javax.inject.Named;

import org.arquillian.a.b.SuperManager;

@Named
public class Manager extends SuperManager{

	@Inject 
	public Handler handler;
}
