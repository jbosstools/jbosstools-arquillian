package org.arquillian.a.b;

import javax.inject.Inject;

import org.arquillian.a.Resource;

public class SuperManager {

	@Inject Resource resource;
}
