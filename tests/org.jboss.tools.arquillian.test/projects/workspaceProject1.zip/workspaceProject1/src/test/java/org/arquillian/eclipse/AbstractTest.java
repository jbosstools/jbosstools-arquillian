package org.arquillian.eclipse;

public abstract class AbstractTest {
}
