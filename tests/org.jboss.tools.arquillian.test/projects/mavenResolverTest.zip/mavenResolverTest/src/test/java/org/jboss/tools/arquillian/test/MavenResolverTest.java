package org.jboss.tools.arquillian.test;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public class MavenResolverTest {

	@Test
	public void test() {
		
	}
	
	@Deployment
	public static Archive<?> createDeployment() {
		return ShrinkWrap.create(WebArchive.class)
				.addAsLibraries(Maven.resolver()
						.loadPomFromClassLoaderResource("pomres.xml")
						.importRuntimeDependencies()
						.resolve()
						.withTransitivity()
						.asFile());
	}
	
}
