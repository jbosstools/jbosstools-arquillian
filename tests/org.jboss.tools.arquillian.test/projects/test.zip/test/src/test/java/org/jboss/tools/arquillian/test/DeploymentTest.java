package org.jboss.tools.arquillian.test;

import static org.junit.Assert.fail;

import org.jboss.arquillian.junit.Arquillian;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public class DeploymentTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
