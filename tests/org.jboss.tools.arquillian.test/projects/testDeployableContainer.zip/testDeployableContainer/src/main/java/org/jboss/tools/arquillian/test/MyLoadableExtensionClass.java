package org.jboss.tools.arquillian.test;

import org.jboss.arquillian.container.spi.client.container.DeployableContainer;
import org.jboss.arquillian.core.spi.LoadableExtension;
import org.jboss.as.arquillian.container.remote.RemoteDeployableContainer;

public class MyLoadableExtensionClass implements LoadableExtension {

	@Override
	public void register(ExtensionBuilder builder) {
		builder.service(DeployableContainer.class, RemoteDeployableContainer.class);
	}
}