package org.arquillian.eclipse;

import static org.junit.Assert.fail;

import javax.inject.Inject;

import org.arquillian.eclipse.Handler;
import org.arquillian.eclipse.Manager;
import org.arquillian.eclipse.SuperManager;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(Arquillian.class)
public class DependentClassValidTest {

	@Inject Manager manager;
	
	@Deployment
	public static Archive<?> createDeployment() {
		WebArchive archive = ShrinkWrap.create(WebArchive.class, "test.war")
				.addClasses( Handler.class, SuperManager.class, Manager.class)
				.addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
		return archive;
	}
	
	@Test
	public void testInjected() {
		fail("Not yet implemented");
	}

}
