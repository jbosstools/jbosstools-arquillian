package org.arquillian.eclipse;

import javax.inject.Inject;
import javax.inject.Named;

@Named
public class Manager extends SuperManager{

	@Inject 
	public Handler handler;
	public String test;
}
