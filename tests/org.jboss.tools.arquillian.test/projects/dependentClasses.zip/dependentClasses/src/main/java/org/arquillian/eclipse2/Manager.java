package org.arquillian.eclipse2;

import javax.inject.Inject;
import javax.inject.Named;

@Named
public class Manager extends SuperManager{

	@Inject 
	public Handler handler;
}
