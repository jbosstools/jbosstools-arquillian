package org.arquillian.eclipse2;

public class Resource {

}
