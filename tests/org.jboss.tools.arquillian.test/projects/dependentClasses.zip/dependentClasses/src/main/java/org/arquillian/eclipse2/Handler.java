package org.arquillian.eclipse2;

import javax.inject.Named;

@Named
public class Handler
{
   public String invoke() {
      return "handler";
   }

}
