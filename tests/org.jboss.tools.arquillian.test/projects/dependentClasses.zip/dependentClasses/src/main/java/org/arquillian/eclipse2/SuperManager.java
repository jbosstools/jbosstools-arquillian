package org.arquillian.eclipse2;

import javax.inject.Inject;

public class SuperManager {

	@Inject Resource resource;
}
