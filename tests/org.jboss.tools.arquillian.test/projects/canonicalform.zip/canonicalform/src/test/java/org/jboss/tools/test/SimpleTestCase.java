package org.jboss.tools.test;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public class SimpleTestCase {

	@Deployment
	public static WebArchive test() {
		return ShrinkWrap.create(WebArchive.class)
				.addAsLibraries(Maven.resolver().resolve("").withoutTransitivity().asFile());
	}

	@Test
	public void shouldX() {
	}

}
