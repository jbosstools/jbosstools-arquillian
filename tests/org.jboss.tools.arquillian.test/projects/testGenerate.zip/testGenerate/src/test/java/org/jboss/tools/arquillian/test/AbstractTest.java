package org.jboss.tools.arquillian.test;

import org.jboss.arquillian.junit.Arquillian;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public abstract class AbstractTest
{
   @Test
   public void testa() {}
}
