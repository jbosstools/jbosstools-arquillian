package org.jboss.tools.arquillian.test;

public class GenerateDeploymentMethodTest extends AbstractTest {

}
