package org.jboss.tools.arquillian;

public class Resource {

}
