package org.jboss.tools.arquillian.test;

import static org.junit.Assert.fail;

import org.jboss.tools.arquillian.Resource;
import org.junit.Test;

public class MyTest extends AbstractTest {

	private Resource resource;
	
	@Test
	public void test() {
		System.out.println(resource);
		fail("Not yet implemented");
	}
	
}
