package org.arquillian;

public class Target {

	public static enum Type {
		Remote, Managed, Embedded
	}
}
