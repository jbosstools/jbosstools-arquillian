package org.arquillian.eclipse;

public class Handler
{
   public String invoke() {
      return "handler";
   }

}
