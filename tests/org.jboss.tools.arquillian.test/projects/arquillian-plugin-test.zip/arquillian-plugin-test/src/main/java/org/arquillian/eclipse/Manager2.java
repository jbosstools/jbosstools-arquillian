package org.arquillian.eclipse;

import org.jboss.arquillian.core.api.annotation.Inject;

public class Manager2 extends SuperManager{

	@Inject Handler handler;
}
