package org.arquillian.eclipse;

public class SuperTestHandler
{

}
