package org.arquillian.eclipse;

import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;

public enum ArchiveBuilder {
	INSTANCE;
	private final WebArchive archive = ShrinkWrap.create(WebArchive.class,
			"shop.war");

	private ArchiveBuilder() {
	}

	public static ArchiveBuilder getInstance() {
		return INSTANCE;
	}
}