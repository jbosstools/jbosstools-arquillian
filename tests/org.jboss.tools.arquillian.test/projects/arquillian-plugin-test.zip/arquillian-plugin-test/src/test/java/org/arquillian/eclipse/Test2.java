package org.arquillian.eclipse;

import static org.junit.Assert.fail;

import javax.inject.Inject;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public class Test2 {

	@Inject SuperTestHandler manager;
	
	@Deployment
	public static Archive<?> deploy() {
		return ShrinkWrap.create(WebArchive.class).addClass(Manager2.class);
	}

	@Test
	public void testInvoke() {
		fail("Not yet implemented");
	}

}
