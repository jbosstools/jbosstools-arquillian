package org.arquillian.eclipse;

import static org.junit.Assert.*;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public class TestSystemExit {

	@Deployment
	public static Archive<?> createDeployment() {
		JavaArchive archive = ShrinkWrap.create(JavaArchive.class, "test.jar")
				.addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
		// System.out.println(archive.toString(true));
		System.exit(0);
		return archive;
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
